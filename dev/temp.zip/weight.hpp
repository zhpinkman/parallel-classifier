struct Weight
{
    double betha0;
    double betha1;
    double bias;
};
