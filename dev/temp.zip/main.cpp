#include <iostream>

int main()
{
    return 0;
}