#include "defs.hpp"

using namespace std;

int main()
{
    map<int, int> cnt;
    cnt[0]++;
    cout << cnt[0] << endl;
    return 0;
}