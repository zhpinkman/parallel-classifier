class Dataset
{
public:
private:
    double width;
    double length;
    double bias;
};